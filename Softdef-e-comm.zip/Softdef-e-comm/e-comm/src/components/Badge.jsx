export default function Badge() {
	return (
		<span className="px-2 py-0.5 bg-red-500 text-white text-xs rounded font-bold">HOT</span>
	);
}